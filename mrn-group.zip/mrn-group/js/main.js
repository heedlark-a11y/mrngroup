/* =========================================
   MRN GROUP
   MAIN JAVASCRIPT
========================================= */
document.addEventListener("DOMContentLoaded", () => {
    /*
     * Mobile Navigation
     */
    const menuButton =
        document.getElementById("mobileMenuButton");
    const mobileNav =
        document.getElementById("mobileNav");
    if (menuButton && mobileNav) {
        menuButton.addEventListener("click", () => {
            const isOpen =
                mobileNav.classList.toggle("is-open");
            menuButton.setAttribute(
                "aria-expanded",
                String(isOpen)
            );
            menuButton.setAttribute(
                "aria-label",
                isOpen
                    ? "Close navigation"
                    : "Open navigation"
            );
        });
        /*
         * Close menu after clicking a link
         */
        mobileNav
            .querySelectorAll("a")
            .forEach(link => {
                link.addEventListener("click", () => {
                    mobileNav.classList.remove("is-open");
                    menuButton.setAttribute(
                        "aria-expanded",
                        "false"
                    );
                    menuButton.setAttribute(
                        "aria-label",
                        "Open navigation"
                    );
                });
            });
    }
    /*
     * Current year
     */
    const yearElement =
        document.getElementById("currentYear");
    if (yearElement) {
        yearElement.textContent =
            new Date().getFullYear();
    }
    /*
     * Close mobile navigation with Escape
     */
    document.addEventListener("keydown", event => {
        if (event.key !== "Escape") {
            return;
        }
        if (!mobileNav || !menuButton) {
            return;
        }
        mobileNav.classList.remove("is-open");
        menuButton.setAttribute(
            "aria-expanded",
            "false"
        );
        menuButton.setAttribute(
            "aria-label",
            "Open navigation"
        );
        menuButton.focus();
    });
});